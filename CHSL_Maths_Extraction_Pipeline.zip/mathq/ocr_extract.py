#!/usr/bin/env python3
"""
OCR extractor v2 for image-QA CHSL Tier-I papers.
Image papers (text layer with Question ID): text layer gives QA pages + answers
(Chosen Option), OCR gives question bodies + options.
Pure scans (2024 English, 2021_23): full OCR; answers from checkmark marks.
"""
import subprocess, re, os, sys, json, tempfile, glob
from concurrent.futures import ThreadPoolExecutor
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from extract import math_score

CD = '/var/tmp/mathq'
TPOOL = ThreadPoolExecutor(max_workers=3)

def run(cmd):
    return subprocess.run(cmd, capture_output=True, text=True).stdout

def n_pages(fn):
    m = re.search(r'Pages:\s+(\d+)', run(['pdfinfo', fn]))
    return int(m.group(1)) if m else 0

def ocr_page(args):
    fn, page, dpi = args
    base = f'/tmp/ocr_{os.getpid()}_{page}'
    try:
        subprocess.run(['pdftoppm', '-f', str(page), '-l', str(page), '-r', str(dpi),
                        '-gray', '-png', fn, base], capture_output=True)
        pngs = glob.glob(base + '*.png')
        if not pngs: return page, ''
        out = subprocess.run(['tesseract', pngs[0], '-', '--psm', '4',
                              '-c', 'preserve_interword_spaces=1'],
                             capture_output=True, text=True)
        return page, out.stdout
    finally:
        for p in glob.glob(base + '*.png'):
            try: os.unlink(p)
            except OSError: pass

def ocr_pages(fn, pages, dpi=200):
    pages = list(pages)
    texts = {}
    for p, t in TPOOL.map(ocr_page, [(fn, p, dpi) for p in pages]):
        texts[p] = t
    return texts

# ---------------- text-layer helpers (image papers) ----------------
def textlayer_qa_info(fn):
    """Return (qa_pages_range, {qnum: chosen_option}) from text layer, or (None, {})."""
    t = run(['pdftotext', fn, '-'])
    pages = t.split('\f')
    qa_p = None
    for i, p in enumerate(pages):
        if re.search(r'Section\s*:\s*Quantitative Aptitude', p) or \
           re.search(r'Quantitative Aptitude\s*\(Basic', p):
            qa_p = i; break
    if qa_p is None:
        return None, {}
    others = ['English Language', 'General Intelligence', 'General Awareness',
              'General Knowledge', 'English Comprehension', 'Reasoning']
    end_p = len(pages)
    for j in range(qa_p + 1, len(pages)):
        if any(re.search(r'Section\s*:\s*' + re.escape(o), pages[j]) for o in others):
            end_p = j + 1
            break
    # QA section text: cut before QA header on start page, before other header on end page
    sec_pages = pages[qa_p:end_p]
    sec = sec_pages[0][sec_pages[0].find('Quantitative Aptitude'):]
    sec += '\f'.join(sec_pages[1:])
    if end_p <= len(pages) - 1 and end_p > qa_p + 1 - 1:
        pass
    # chosen options: pairs of Q.N ... Chosen Option : X in order
    chosen = {}
    blocks = re.split(r'Q\s*\.\s*(\d{1,3})', sec)
    # blocks: [pre, n1, body1, n2, body2, ...]
    for i in range(1, len(blocks) - 1, 2):
        n = int(blocks[i])
        mm = re.search(r'Chosen[ \t]*Option[ \t]*:?[ \t]*([1-4])', blocks[i + 1])
        if mm and n not in chosen:
            chosen[n] = int(mm.group(1))
    return range(qa_p + 1, end_p + 1), chosen

# ---------------- OCR parsing ----------------
QMARK = re.compile(r'(?:^|\n)[ \t]*(?:Section[^\n]*\n[ \t]*)?[Qq9a][\s\.\,]*?(\d{1,3})[\.\)_\-]*[ \t]*', re.M)
OPT_PRE = r'[Xx✗×%*#¥~✓vVSA>@KJFWwOf]{0,2}'

def ocr_section_text(texts, pages):
    """Join OCR pages; cut before QA header (start page) and at next section header."""
    full = '\n'.join(texts[p] for p in sorted(texts))
    # find QA header followed by a Q.N within 3000 chars
    m_qa = None
    for m in re.finditer(r'(?:Section\s*:\s*)?Quantitative\s+Aptitude', full):
        if re.search(r'Q\s*[\.\,]?\s*\d', full[m.end():m.end() + 3000]):
            m_qa = m; break
    if m_qa is None:
        return None
    sec = full[m_qa.end():]
    # cut at next different section header (not near start)
    m_next = None
    for m in re.finditer(r'Section\s*:\s*(English|General|Reasoning|Numerical)[^\n]*', sec):
        if m.start() > 500:
            m_next = m; break
    if m_next is None:
        for m in re.finditer(r'\n[ \t]*(English Language|General Intelligence|General Awareness|General Knowledge|Reasoning)[ \t]*\n', sec):
            if m.start() > 500:
                m_next = m; break
    if m_next: sec = sec[:m_next.start()]
    return sec

BARE = re.compile(r'(?:^|\n)[ \t]*(\d{1,2})[\.\)_]*[ \t]+(?=[A-Z0-9₹(])')

def parse_seq(sec, expect_start=1, expect_end=25):
    """Sequentially assign Q numbers, fixing OCR misreads (Q.3 -> 23 etc.)."""
    marks = [(m.start(1), int(m.group(1)), m.end(), False) for m in QMARK.finditer(sec)]
    marks += [(m.start(1), int(m.group(1)), m.end(), True) for m in BARE.finditer(sec)]
    marks.sort(key=lambda x: x[0])
    out = []
    expected = expect_start
    for st, n, en, is_bare in marks:
        if is_bare and not (n == expected or n == expected + 20):
            continue
        if n == expected:
            out.append((st, n, en)); expected += 1
        elif n == expected + 20 and expected + 20 <= expect_end + 20:
            # "23" misread of "Q.3" (Q->2) — accept as expected
            out.append((st, expected, en)); expected += 1
        elif expect_start <= n <= expect_end and n > expected:
            # jumped ahead (a marker was lost) — accept
            out.append((st, n, en)); expected = n + 1
        elif n < expect_start or n > expect_end:
            continue  # out of section range (other section's Q)
        # else: n < expected (dup/backward) -> skip
    return out

OPT_MARK = re.compile(
    r'(?:^|\n|\s{2,}|\s)[ \t]*(\S{0,2})[ \t]*([1-4])[\.\)][ \t]*')
CHK = re.compile(r'[✓¥~vV>SA]{1,2}$')
XMK = re.compile(r'[Xx✗×%*#]{1,2}$')

def parse_ocr_body(n, body, chosen=None):
    body = re.sub(r'(Question ID[^\n]*|Status[^\n]*|Chosen Option[^\n]*|Page[ \t]*-?[ \t]*\d+[^\n]*|\f)', '\n', body)
    qtext, opt_zone = body, None
    m_ans = re.search(r'(?:^|\n)[ \t]*(?:Ans|Answer)[ \t]*:?[ \t]*(?=\n|[1-4Xx✗×%*#¥~✓vV>SA])', body)
    if m_ans:
        qtext, opt_zone = body[:m_ans.start()], body[m_ans.end():]
    else:
        mm = list(re.finditer(r'(?:^|\n)[ \t]*(?:' + OPT_PRE + r')[ \t]*1[\.\)][ \t]*', body))
        if mm:
            qtext, opt_zone = body[:mm[-1].start()], body[mm[-1].start():]
    opts, marks_clean = {}, []
    if opt_zone:
        oms = []
        for m in OPT_MARK.finditer(opt_zone):
            if m.group(2) is not None:
                oms.append((m.start(), m.end(), (m.group(1) or '').strip(), int(m.group(2))))
            else:
                oms.append((m.start(), m.end(), (m.group(3) or '').strip(), int(m.group(4))))
        # last full run of 1..4
        run_ = []
        for i in range(len(oms) - 1, -1, -1):
            run_.insert(0, oms[i])
            if oms[i][3] == 1: break
        run4 = run_[:4]
        if [r[3] for r in run4] == [1, 2, 3, 4]:
            for k, (st, en, pfx, num) in enumerate(run4):
                e = run4[k + 1][0] if k + 1 < len(run4) else len(opt_zone)
                val = re.sub(r'\s*\n\s*', ' ', opt_zone[en:e]).strip()
                val = re.split(r'\n\s*\n', val)[0]
                val = re.split(r'\s{2,}|\s' + OPT_PRE + r'\s*[1-4][\.\)]', val)[0].strip()
                val = re.sub(r'\s*Q\.?$|\s*[Xx✗×%*#¥~✓vVSA>@KJFWwOf]{1,2}$', '', val).strip()
                L = 'ABCD'[num - 1]
                opts[L] = val[:120]
                marks_clean.append((num, pfx, opts[L]))
        elif len(run_) >= 2 and [r[3] for r in run_[:len(run_)]] and run_[0][3] == 1:
            # partial run: accept what we have (1..k)
            for k, (st, en, pfx, num) in enumerate(run_):
                if num > 4: break
                e = run_[k + 1][0] if k + 1 < len(run_) else len(opt_zone)
                val = re.sub(r'\s*\n\s*', ' ', opt_zone[en:e]).strip()
                val = re.split(r'\n\s*\n', val)[0]
                val = re.split(r'\s{2,}|\s' + OPT_PRE + r'\s*[1-4][\.\)]', val)[0].strip()
                val = re.sub(r'\s*Q\.?$|\s*[Xx✗×%*#¥~✓vVSA>@KJFWwOf]{1,2}$', '', val).strip()
                L = 'ABCD'[num - 1]
                opts[L] = val[:120]
                marks_clean.append((num, pfx, opts[L]))
    ans = None; how = None
    if chosen in (1, 2, 3, 4):
        ans = 'ABCD'[chosen - 1]; how = 'chosen'
    if marks_clean:
        chk = [num for num, pfx, v in marks_clean if pfx and re.fullmatch(r'[✓¥~vV]{1,2}', pfx)]
        XFAM = re.compile(r'^[Xx✗×%*]')
        no_x = [num for num, pfx, v in marks_clean if not (pfx and XFAM.match(pfx))]
        a2 = None
        if len(chk) == 1:
            a2 = 'ABCD'[chk[0] - 1]
        elif len(no_x) == 1:
            a2 = 'ABCD'[no_x[0] - 1]
        if a2:
            if ans and a2 != ans:
                how = 'conflict'
            else:
                ans = a2; how = (how or '') + '+mark'
    qtext = ' '.join(qtext.split())
    qtext = re.sub(r'^[_\-\.\s]+', '', qtext)
    flags = []
    if len(opts) != 4: flags.append('OPTIONS_' + str(len(opts)))
    if not ans: flags.append('NO_ANS')
    if len(qtext) < 15: flags.append('SHORT_TEXT')
    if how == 'conflict': flags.append('ANS_CONFLICT')
    return {'n': n, 'text': qtext, 'options': opts, 'ans': ans, 'flags': flags,
            'ans_src': how, 'src': 'OCR'}

def extract_image_paper(fn, dpi=200):
    """Image-QA paper with text layer."""
    rng, chosen = textlayer_qa_info(fn)
    if rng is None:
        return None
    texts = ocr_pages(fn, rng, dpi)
    sec = ocr_section_text(texts, rng)
    if sec is None:
        # maybe header didn't OCR; try full text of range
        sec = '\n'.join(texts[p] for p in sorted(texts))
    marks = parse_seq(sec, 1, 25)
    qs = []
    for k, (st, n, en) in enumerate(marks):
        nxt = marks[k + 1][0] if k + 1 < len(marks) else len(sec)
        qs.append(parse_ocr_body(n, sec[en:nxt], chosen.get(n)))
    return qs

def extract_scan_paper(fn, expect_start=1, dpi=200):
    """Pure-scan paper (2024E, 2021_23): OCR all pages, find QA, parse.
    Header-based first; fallback: math-score the Q.1 candidates.
    Returns (questions, qa_pages)."""
    n = n_pages(fn)
    texts = ocr_pages(fn, range(1, n + 1), dpi)
    full = '\n'.join(texts[p] for p in sorted(texts))
    page_off, off = [], 0
    for p in range(1, n + 1):
        page_off.append((off, off + len(texts.get(p, '')) + 1, p))
        off += len(texts.get(p, '')) + 1

    def pages_for_span(s, e):
        return [p for a, b, p in page_off if not (e < a or s > b)] or list(range(1, n + 1))

    best = (None, 0, list(range(1, n + 1)))  # (qs, count, pages)

    def try_sec(sec, es, base_off):
        nonlocal best
        marks = parse_seq(sec, es, es + 24)
        qs = []
        for k, (st, n_, en) in enumerate(marks):
            nxt = marks[k + 1][0] if k + 1 < len(marks) else len(sec)
            qs.append(parse_ocr_body(n_, sec[en:nxt], None))
        if len(qs) > best[1]:
            best = (qs, len(qs), pages_for_span(base_off, base_off + min(len(sec), 9500)))

    # 1) header-based
    m_qa = None
    for m in re.finditer(r'(?:Section\s*:\s*)?Quantitative\s+Aptitude', full):
        if re.search(r'Q\s*[\.,]?\s*\d', full[m.end():m.end() + 3000]):
            m_qa = m; break
    if m_qa is not None:
        rest = full[m_qa.end():]
        m_next = None
        for m in re.finditer(r'Section\s*:\s*(English|General|Reasoning|Numerical)[^\n]*', rest):
            if m.start() > 500:
                m_next = m; break
        sec = rest[:m_next.start()] if m_next else rest[:9000]
        try_sec(sec, expect_start, m_qa.end())
    # 2) math-score Q.N start candidates
    if best[1] < 20:
        for m in re.finditer(r'(?:^|\n)[ \t]*Q\s*[\.,]?\s*([1-9]|1[0-9]|2[0-5])[\.\)]?[ \t]*(?=[A-Z0-9(₹])', full):
            start_n = int(m.group(1))
            after = full[m.end():m.end() + 2500]
            if math_score(after) < 40: continue
            try_sec(full[m.end():m.end() + 16000], start_n, m.end())
            if best[1] >= 25: break
    return best[0], best[2], texts


if __name__ == '__main__':
    fn = sys.argv[1]
    mode = sys.argv[2] if len(sys.argv) > 2 else 'image'
    if mode == 'scan':
        r = extract_scan_paper(fn, expect_start=int(sys.argv[3]) if len(sys.argv) > 3 else 1)
        qs = r[0] if isinstance(r, tuple) else r
    else:
        qs = extract_image_paper(fn)
    if qs is None:
        print("FAILED to locate/parse QA"); sys.exit(1)
    print(f"parsed {len(qs)} questions")
    nok = sum(1 for q in qs if q['ans'])
    n4 = sum(1 for q in qs if len(q['options']) == 4)
    print(f"answers: {nok}/{len(qs)} | 4-options: {n4}/{len(qs)}")
    for q in qs[:5]:
        print(f"\nQ{q['n']} [{','.join(q['flags'])}] ans={q['ans']}({q['ans_src']})")
        print("  ", q['text'][:100])
        print("   opts:", dict(list(q['options'].items())[:4]))
