#!/usr/bin/env python3
"""Spatial color answers: green checkmark -> nearest 'Ans' word -> Q.N word above.
Returns {qnum: (option_letter, option_line_text)} per paper."""
import subprocess, glob, re, os
from PIL import Image
from concurrent.futures import ThreadPoolExecutor

def _page_work(args):
    fn, page, dpi = args
    base = f'/tmp/sp_{os.getpid()}_{page}'
    for p in glob.glob(base + '*.png'):
        try: os.unlink(p)
        except OSError: pass
    try:
        subprocess.run(['pdftoppm', '-f', str(page), '-l', str(page), '-r', str(dpi),
                        '-png', fn, base], capture_output=True)
        pngs = glob.glob(base + '*.png')
        if not pngs: return {}
        img = Image.open(pngs[0]).convert('RGB')
        W, H = img.size
        px = img.load()
        greens = []
        for y in range(H):
            for x in range(0, W, 2):
                r, g, b = px[x, y]
                if g > 115 and g > r + 33 and g > b + 33:
                    greens.append((x, y))
        if not greens: return {}
        ys = sorted(set(y for _, y in greens))
        clusters = []
        for y in ys:
            if clusters and y - clusters[-1][-1] <= 6:
                clusters[-1].append(y)
            else:
                clusters.append([y])
        centers = [sum(c) / len(c) for c in clusters if 6 <= len(c) <= 70]
        if not centers: return {}
        tsv = subprocess.run(['tesseract', pngs[0], '-', '--psm', '4', 'tsv'],
                             capture_output=True, text=True).stdout
        words = []
        for line in tsv.split('\n')[1:]:
            f = line.split('\t')
            if len(f) < 12: continue
            try:
                x, y, w, h = int(f[6]), int(f[7]), int(f[8]), int(f[9])
            except ValueError: continue
            t = f[11].strip()
            if t: words.append((x, y, w, h, t))
        # Q-marker words: "Q.5", "Q5", "05", "a5"...
        qwords = []
        for x, y, w, h, t in words:
            m = re.match(r'^[Qq9aOo][\s\.,]?\s*(\d{1,3})[\s\.,\)]?$', t)
            if m and x < 400:
                qwords.append((y, int(m.group(1))))
        # Ans words at left margin
        answords = [(y + h / 2) for x, y, w, h, t in words
                    if t.lower().rstrip('.)').startswith('ans') and len(t) <= 5 and x < 400]
        out = {}
        for cy in centers:
            # option line words near cy
            optw = sorted([wd for wd in words if wd[1] - 14 <= cy <= wd[1] + wd[3] + 14 and wd[0] < 700],
                          key=lambda wd: wd[0])
            opt_text = ' '.join(wd[4] for wd in optw[:8])
            nums = []
            for n in re.findall(r'([1-4])[\.\)]', opt_text):
                if n not in nums: nums.append(n)
            if len(nums) != 1: continue
            num = int(nums[0])
            # nearest Ans word below/above
            if not answords: continue
            ay = min(answords, key=lambda a: abs(a - cy))
            if abs(ay - cy) > 120: continue
            # Q word above the Ans line
            above = [qn for qy, qn in qwords if qy <= ay + 15]
            if not above: continue
            qn = above[-1]
            if qn not in out:
                out[qn] = ('ABCD'[num - 1], opt_text)
        return out
    finally:
        for p in glob.glob(base + '*.png'):
            try: os.unlink(p)
            except OSError: pass

def spatial_answers(fn, pages, dpi=200, workers=3):
    res = {}
    with ThreadPoolExecutor(max_workers=workers) as ex:
        for r in ex.map(_page_work, [(fn, p, dpi) for p in pages]):
            for k, v in r.items():
                if k not in res:
                    res[k] = v
    return res

if __name__ == '__main__':
    import sys
    fn = sys.argv[1]
    pages = [int(x) for x in sys.argv[2:]]
    sa = spatial_answers(fn, pages)
    for qn in sorted(sa):
        print(f"Q{qn}: {sa[qn][0]}  <- {sa[qn][1][:60]}")


def _page_words_and_marks(fn, page, dpi=200):
    """words + green mark centers for one page."""
    base = f'/tmp/sp2_{os.getpid()}_{page}'
    for p in glob.glob(base + '*.png'):
        try: os.unlink(p)
        except OSError: pass
    try:
        subprocess.run(['pdftoppm', '-f', str(page), '-l', str(page), '-r', str(dpi),
                        '-png', fn, base], capture_output=True)
        pngs = glob.glob(base + '*.png')
        if not pngs: return [], []
        img = Image.open(pngs[0]).convert('RGB')
        W, H = img.size
        px = img.load()
        greens = []
        for y in range(H):
            for x in range(0, W, 2):
                r, g, b = px[x, y]
                if g > 115 and g > r + 33 and g > b + 33:
                    greens.append((x, y))
        ys = sorted(set(y for _, y in greens))
        clusters = []
        for y in ys:
            if clusters and y - clusters[-1][-1] <= 6:
                clusters[-1].append(y)
            else:
                clusters.append([y])
        centers = [sum(c) / len(c) for c in clusters if 6 <= len(c) <= 70]
        tsv = subprocess.run(['tesseract', pngs[0], '-', '--psm', '4', 'tsv'],
                             capture_output=True, text=True).stdout
        words = []
        for line in tsv.split('\n')[1:]:
            f = line.split('\t')
            if len(f) < 12: continue
            try:
                x, y, w, h = int(f[6]), int(f[7]), int(f[8]), int(f[9])
            except ValueError: continue
            if f[11].strip(): words.append((x, y, w, h, f[11].strip()))
        return words, centers
    finally:
        for p in glob.glob(base + '*.png'):
            try: os.unlink(p)
            except OSError: pass


def ans_order_answers(fn, pages, page_texts, questions):
    """Map green marks to questions via Ans-word order per page.
    page_texts: {page: normalized ocr text}; questions need 'text'."""
    import re as _re
    def nrm(s):
        return _re.sub(r'[^a-z0-9]+', '', s.lower())
    # question -> page via fragment search
    qpage = {}
    for q in questions:
        frag = nrm(q.get('text', ''))[:32]
        if len(frag) < 10: continue
        for p in pages:
            if frag in nrm(page_texts.get(p, '')):
                qpage[q['n']] = p
                break
    out = {}
    from concurrent.futures import ThreadPoolExecutor
    with ThreadPoolExecutor(max_workers=3) as ex:
        res = list(ex.map(lambda p: (p, _page_words_and_marks(fn, p)), pages))
    for p, (words, centers) in res:
        pqs = [q for q in questions if qpage.get(q['n']) == p]
        if not pqs or not centers: continue
        answords = sorted([(y + h / 2) for x, y, w, h, t in words
                           if t.lower().rstrip('.)').startswith('ans') and len(t) <= 5 and x < 400])
        if not answords: continue
        pqs_sorted = sorted(pqs, key=lambda q: nrm(page_texts.get(p, '')).find(nrm(q['text'])[:32]))
        for cy in centers:
            ay = min(answords, key=lambda a: abs(a - cy))
            if abs(ay - cy) > 120: continue
            k = answords.index(ay)
            if k >= len(pqs_sorted): continue
            optw = sorted([wd for wd in words if wd[1] - 14 <= cy <= wd[1] + wd[3] + 14 and wd[0] < 700],
                          key=lambda wd: wd[0])
            opt_text = ' '.join(wd[4] for wd in optw[:8])
            nums = []
            for n2 in _re.findall(r'([1-4])[\.)]', opt_text):
                if n2 not in nums: nums.append(n2)
            if len(nums) != 1: continue
            qn = pqs_sorted[k]['n']
            if qn not in out:
                out[qn] = ('ABCD'[int(nums[0]) - 1], opt_text)
    return out
