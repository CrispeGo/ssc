#!/usr/bin/env python3
"""Batch OCR runner. Usage: batch_ocr.py <list-file>  (lines: fn<TAB>mode<TAB>expect)"""
import sys, os, json, time, traceback
sys.path.insert(0, '/var/tmp/mathq')
os.chdir('/var/tmp/mathq')
from ocr_extract import extract_image_paper, extract_scan_paper

CD = '/var/tmp/mathq'
OUT = os.path.join(CD, 'ocr_out')
os.makedirs(OUT, exist_ok=True)

def main(listfile):
    jobs = []
    for line in open(listfile):
        line = line.strip()
        if not line: continue
        parts = line.split('\t')
        fn, mode = parts[0], parts[1]
        es = int(parts[2]) if len(parts) > 2 and parts[2] else 1
        jobs.append((fn, mode, es))
    for fn, mode, es in jobs:
        outp = os.path.join(OUT, fn.replace('.pdf', '.json'))
        if os.path.exists(outp):
            print(f"SKIP {fn} (done)", flush=True)
            continue
        t0 = time.time()
        try:
            if mode == 'image':
                qs = extract_image_paper(os.path.join(CD, fn))
            else:
                qs = extract_scan_paper(os.path.join(CD, fn), es)
            if qs is None:
                qs = []
                stat = 'FAILED'
            else:
                stat = f"{len(qs)}Q a{sum(1 for q in qs if q['ans'])} o4_{sum(1 for q in qs if len(q['options'])==4)}"
            json.dump(qs, open(outp, 'w'), ensure_ascii=False)
            print(f"OK {fn}: {stat} ({time.time()-t0:.0f}s)", flush=True)
        except Exception as e:
            print(f"ERR {fn}: {e}", flush=True)
            traceback.print_exc()
            json.dump([], open(outp, 'w'), ensure_ascii=False)

if __name__ == '__main__':
    main(sys.argv[1])
