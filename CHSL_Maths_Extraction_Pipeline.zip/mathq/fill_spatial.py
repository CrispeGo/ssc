#!/usr/bin/env python3
"""Final answer fill: spatial color answers + value verification.
Image papers: text-layer Chosen Option primary, spatial fills gaps.
Scan papers: fresh extract + spatial."""
import sys, os, json, time
sys.path.insert(0, '/var/tmp/mathq')
os.chdir('/var/tmp/mathq')
from ocr_extract import textlayer_qa_info, extract_scan_paper
from spatial import spatial_answers
from colorans import norm

CD = '/var/tmp/mathq'
OUT = os.path.join(CD, 'ocr_out')

def verify(q, letter, line_text):
    """Value-consistency check when question has parsed options."""
    v = (q.get('options') or {}).get(letter, '')
    if not v: return True  # nothing to check against
    vn, ltn = norm(v), norm(line_text)
    if not vn or len(vn) < 3: return True
    return vn[:10] in ltn or ltn[:14] in vn

def fill_image(fn):
    outp = os.path.join(OUT, fn.replace('.pdf', '.json'))
    qs = json.load(open(outp))
    before = sum(1 for q in qs if q.get('ans'))
    need = [q for q in qs if not q.get('ans')]
    if need:
        rng, chosen = textlayer_qa_info(os.path.join(CD, fn))
        if rng is not None:
            sa = spatial_answers(os.path.join(CD, fn), list(rng))
            for q in qs:
                if q.get('ans'): continue
                hit = sa.get(q['n'])
                if hit and verify(q, hit[0], hit[1]):
                    q['ans'] = hit[0]; q['ans_src'] = 'spatial'
                    q['flags'] = [f for f in q['flags'] if f != 'NO_ANS']
    after = sum(1 for q in qs if q.get('ans'))
    json.dump(qs, open(outp, 'w'), ensure_ascii=False)
    return before, after, len(qs)

def fill_scan(fn, expect=1):
    outp = os.path.join(OUT, fn.replace('.pdf', '.json'))
    res = extract_scan_paper(os.path.join(CD, fn), expect)
    if isinstance(res, tuple):
        qs, pages, texts = (res + ({},))[:3] if len(res) == 3 else (res[0], res[1], {})
    else:
        qs, pages, texts = res, [], {}
    if qs is None: qs = []
    # keep the better of existing vs fresh (300dpi recovery may be better)
    if os.path.exists(outp):
        old_qs = json.load(open(outp))
        if len(old_qs) > len(qs):
            qs = old_qs  # keep recovered; use fresh pages/texts for spatial
    before = sum(1 for q in qs if q.get('ans'))
    if pages and qs:
        sa = spatial_answers(os.path.join(CD, fn), pages)
        for q in qs:
            if q.get('ans'): continue
            hit = sa.get(q['n'])
            if hit and verify(q, hit[0], hit[1]):
                q['ans'] = hit[0]; q['ans_src'] = 'spatial'
                q['flags'] = [f for f in q['flags'] if f != 'NO_ANS']
            elif hit and not q.get('options'):
                q['ans'] = hit[0]; q['ans_src'] = 'spatial'
                q['ans_note'] = hit[1]
                q['flags'] = [f for f in q['flags'] if f != 'NO_ANS']
        # fallback: ans-order mapping for the rest
        remaining = [q for q in qs if not q.get('ans')]
        if remaining:
            from spatial import ans_order_answers
            ao = ans_order_answers(os.path.join(CD, fn), pages, texts, qs)
            for q in remaining:
                hit = ao.get(q['n'])
                if hit and verify(q, hit[0], hit[1]):
                    q['ans'] = hit[0]; q['ans_src'] = 'ansorder'
                    q['flags'] = [f for f in q['flags'] if f != 'NO_ANS']
                elif hit and not q.get('options'):
                    q['ans'] = hit[0]; q['ans_src'] = 'ansorder'
                    q['ans_note'] = hit[1]
                    q['flags'] = [f for f in q['flags'] if f != 'NO_ANS']
    after = sum(1 for q in qs if q.get('ans'))
    json.dump(qs, open(outp, 'w'), ensure_ascii=False)
    return before, after, len(qs)

if __name__ == '__main__':
    mode = sys.argv[1]
    files = [l.strip() for l in open(sys.argv[2]) if l.strip()]
    for fn in files:
        t0 = time.time()
        try:
            b, a, n = (fill_image if mode == 'image' else fill_scan)(fn)
            print(f"{fn}: {b} -> {a} / {n}Q ({time.time()-t0:.0f}s)", flush=True)
        except Exception as e:
            import traceback; traceback.print_exc()
            print(f"ERR {fn}: {e}", flush=True)
