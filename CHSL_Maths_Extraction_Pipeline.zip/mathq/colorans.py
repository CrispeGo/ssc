#!/usr/bin/env python3
"""Color-based answer detection: green checkmark lines per page via tesseract TSV."""
import subprocess, glob, re, os
from PIL import Image
from concurrent.futures import ThreadPoolExecutor

def green_lines_page(fn, page, dpi=200):
    """Return list of green-marked option-line texts (words near each green mark)."""
    base = f'/tmp/ga_{os.getpid()}_{page}'
    for p in glob.glob(base + '*.png'):
        try: os.unlink(p)
        except OSError: pass
    try:
        subprocess.run(['pdftoppm', '-f', str(page), '-l', str(page), '-r', str(dpi),
                        '-png', fn, base], capture_output=True)
        pngs = glob.glob(base + '*.png')
        if not pngs: return []
        img = Image.open(pngs[0]).convert('RGB')
        W, H = img.size
        px = img.load()
        greens = []
        for y in range(H):
            for x in range(0, W, 2):
                r, g, b = px[x, y]
                if g > 115 and g > r + 33 and g > b + 33:
                    greens.append((x, y))
        if not greens: return []
        ys = sorted(set(y for _, y in greens))
        clusters = []
        for y in ys:
            if clusters and y - clusters[-1][-1] <= 6:
                clusters[-1].append(y)
            else:
                clusters.append([y])
        # checkmark-sized clusters
        centers = []
        for c in clusters:
            if 6 <= len(c) <= 70:
                xs = [x for x, y in greens if y in c]
                centers.append((sum(c) / len(c), min(xs), max(xs)))
        if not centers: return []
        tsv = subprocess.run(['tesseract', pngs[0], '-', '--psm', '4', 'tsv'],
                             capture_output=True, text=True).stdout
        words = []
        for line in tsv.split('\n')[1:]:
            f = line.split('\t')
            if len(f) < 12: continue
            try:
                x, y, w, h = int(f[6]), int(f[7]), int(f[8]), int(f[9])
            except ValueError: continue
            t = f[11].strip()
            if t: words.append((x, y, w, h, t))
        out = []
        for cy, cx0, cx1 in centers:
            near = [w for w in words if w[1] - 12 <= cy <= w[1] + w[3] + 12 and w[0] < 700]
            near.sort(key=lambda w: w[0])
            out.append(' '.join(w[4] for w in near[:8]))
        return out
    finally:
        for p in glob.glob(base + '*.png'):
            try: os.unlink(p)
            except OSError: pass

def green_lines_paper(fn, pages, workers=3):
    res = {}
    with ThreadPoolExecutor(max_workers=workers) as ex:
        for p, lines in ex.map(lambda p: (p, green_lines_page(fn, p)), pages):
            res[p] = lines
    return res

def norm(s):
    return re.sub(r'[^\w°]+', '', s).lower()

def line_option(lt):
    """Candidate option numbers in a green line: digits 1-4 followed by ./)."""
    nums = []
    for n in re.findall(r'([1-4])[\.\)]', lt):
        if n not in nums: nums.append(n)
    return nums

def match_answers(questions, glines_by_page):
    """Monotonic green-line matching: lines are in question order.
    Phase 1: value-verified; Phase 2: number-only (incl. option-less questions)."""
    lines = []
    for p in sorted(glines_by_page):
        for lt in glines_by_page[p]:
            if lt.strip(): lines.append(lt)
    li = 0

    def optnum(lt):
        c = line_option(lt)
        return int(c[0]) if len(c) == 1 else None

    # ---- phase 1: questions with options, value-verified ----
    for q in questions:
        if q.get('ans') or not q.get('options'): continue
        for j in range(li, len(lines)):
            num = optnum(lines[j])
            if num is None: continue
            L = 'ABCD'[num - 1]
            v = q['options'].get(L, '')
            if not v: continue
            vn, ltn = norm(v), norm(lines[j])
            if vn and len(vn) >= 3 and vn[:10] in ltn:
                q['ans'] = L; q['ans_src'] = (q.get('ans_src') or '') + '+color'
                q['flags'] = [f for f in q['flags'] if f != 'NO_ANS']
                li = j + 1
                break
    # ---- phase 2: remaining questions, number-only ----
    li2 = 0
    for q in questions:
        if q.get('ans'): continue
        for j in range(li2, len(lines)):
            num = optnum(lines[j])
            if num is None: continue
            L = 'ABCD'[num - 1]
            has_opt = bool(q.get('options', {}).get(L))
            # value-consistency if option exists
            if q.get('options') and q['options'].get(L):
                v = q['options'][L]
                vn, ltn = norm(v), norm(lines[j])
                if vn and len(vn) >= 3 and vn[:10] not in ltn:
                    continue  # value mismatch -> not this question's line
            q['ans'] = L
            q['ans_src'] = (q.get('ans_src') or '') + '+color2'
            q['flags'] = [f for f in q['flags'] if f != 'NO_ANS']
            if not q.get('options'):
                q['ans_note'] = lines[j]
            li2 = j + 1
            break
    return questions
