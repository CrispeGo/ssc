#!/usr/bin/env python3
"""
CHSL Tier-I Math (QA) extractor v4 — TEXT papers (2017-2023).
- 2017/2018: bbox 2-col reading order, all questions, math block by scoring
- 2019:      bbox 2-col, QA page-range + y-cut section, Q1-25 (mixed option styles)
- 2021-2023: plain text, QA header section (NOHDR: whole text + window select)
Output: extracted.json {fn: [question dict]}
"""
import subprocess, re, json, os, sys, html

CD = '/var/tmp/mathq'

def run(args):
    return subprocess.run(args, capture_output=True, text=True).stdout

# ---------------- bbox 2-col ----------------
def get_lines(fn):
    xml = subprocess.run(['pdftotext', '-bbox-layout', fn, '-'], capture_output=True, text=True).stdout
    out = []
    for m in re.finditer(r'<page width="([\d.]+)" height="([\d.]+)">(.*?)</page>', xml, re.S):
        w, h, body = float(m.group(1)), float(m.group(2)), m.group(3)
        lines = []
        for lm in re.finditer(r'<line xMin="([\d.]+)" yMin="([\d.]+)" xMax="([\d.]+)" yMax="([\d.]+)">(.*?)</line>', body, re.S):
            x0, y0, x1, y1 = map(float, lm.groups()[:4])
            words = re.findall(r'<word xMin="[\d.]+" yMin="[\d.]+" xMax="[\d.]+" yMax="[\d.]+">(.*?)</word>', lm.group(5))
            lines.append((x0, y0, x1, y1, html.unescape(' '.join(words))))
        out.append((w, h, lines))
    return out

def col_rows(lines):
    """Group y-sorted lines into rows (y within 5pt)."""
    lines = sorted(lines, key=lambda l: (l[1], l[0]))
    rows = []
    for l in lines:
        if rows and abs(l[1] - rows[-1][0][1]) <= 5:
            rows[-1].append(l)
        else:
            rows.append([l])
    return rows

def page_2col_text(w, h, lines):
    mid = w / 2
    txt = []
    for col in (lambda l: l[0] < mid, lambda l: l[0] >= mid):
        cl = [l for l in lines if col(l)]
        for row in col_rows(cl):
            row.sort(key=lambda l: l[0])
            txt.append('   '.join(l[4] for l in row))
    return '\n'.join(txt)

HDR_NAMES = ['Quantitative Aptitude', 'Numerical Aptitude', 'General Intelligence',
             'General Awareness', 'General Knowledge', 'English Language',
             'English Comprehension', 'Reasoning']

def find_hdr(lines, which):
    """which = 'qa' or 'other'. Return yMin of header line or None."""
    for x0, y0, x1, y1, txt in lines:
        t = txt.strip()
        base = re.sub(r'^Section\s*:\s*', '', t)
        for nm in ([HDR_NAMES[0], HDR_NAMES[1]] if which == 'qa' else HDR_NAMES[2:]):
            if base == nm or (nm in t and len(t) < 60 and ('Section' in t or base == nm)):
                return y0
    return None

def qa_section_bbox(fn):
    """QA section text via bbox geometry (2-col papers)."""
    pages = get_lines(fn)
    qa_hits = []  # (page_idx, y)
    for i, (w, h, lines) in enumerate(pages):
        y = find_hdr(lines, 'qa')
        if y is not None:
            qa_hits.append((i, y))
    for pi, py in qa_hits:
        end_pg, end_y = None, None
        for j in range(pi + 1, len(pages)):
            ey = find_hdr(pages[j][2], 'other')
            if ey is not None:
                end_pg, end_y = j, ey
                break
        sec = ''
        rng = range(pi, end_pg + 1) if end_pg is not None else range(pi, len(pages))
        for i in rng:
            w, h, lines = pages[i]
            ls = list(lines)
            if i == pi:
                ls = [l for l in ls if l[1] >= py - 1]
            if end_pg is not None and i == end_pg:
                ls = [l for l in ls if l[1] < end_y - 1]
            sec += page_2col_text(w, h, ls) + '\n'
        n_marks = len(re.findall(r'(?:^|\n)[ \t]*\d{1,3}\.', sec))
        if n_marks >= 18:
            return sec
    return None

def full_2col_text(fn):
    pages = get_lines(fn)
    return '\n'.join(page_2col_text(w, h, lines) for w, h, lines in pages)

# ---------------- plain text ----------------
def text_plain(fn):
    return run(['pdftotext', fn, '-'])

def qa_section_plain(t):
    marks = []
    for h_ in HDR_NAMES:
        for m in re.finditer(r'(?:^|\n)[ \t]*(?:Section[ \t]*:[ \t]*)?' + re.escape(h_) + r'[ \t]*(?:\n|$)', t):
            marks.append([m.start(), m.end(), h_])
    marks.sort()
    qa_idx = [i for i, mk in enumerate(marks) if mk[2] in ('Quantitative Aptitude', 'Numerical Aptitude')]
    if not qa_idx:
        return None
    i = qa_idx[0]
    start = marks[i][1]
    end = len(t)
    for j in range(i + 1, len(marks)):
        if marks[j][2] not in ('Quantitative Aptitude', 'Numerical Aptitude') and marks[j][0] >= start:
            end = marks[j][0]
            break
    return t[start:end]

def is_image_qa(sec):
    if sec is None: return False
    head = sec[:3000]
    if 'Question ID' not in head: return False
    body = re.sub(r'(Question ID[^\n]*|Status[^\n]*|Chosen Option[^\n]*|Page-?[ \t]*\d+|https?://\S+|Section[^\n]*|^[ \t]*Ans[ \t]*$|^[ \t]*[1-4]\.[ \t]*$|^[ \t]*Q\.\d+[ \t]*$)', '', head, flags=re.M)
    return len(re.findall(r'[A-Za-z]{3,}', body)) < 120

# ---------------- markers & parsing ----------------
MARK = re.compile(r'(?:^|\n|\f)[ \t]*(\d{1,3})\.(?![\d.])[ \t]*', re.M)

def all_markers(sec):
    return [(m.start(1), int(m.group(1)), m.end()) for m in MARK.finditer(sec)]

def runs_of(markers):
    runs, cur = [], []
    for st, n, en in markers:
        if cur and cur[-1][1] + 1 <= n <= cur[-1][1] + 2:
            cur.append((st, n, en))
        else:
            if len(cur) >= 8: runs.append(cur)
            cur = [(st, n, en)]
    if len(cur) >= 8: runs.append(cur)
    return runs

def best_chain(markers):
    """Longest subsequence with steps of 1 or 2 (drops false intruders). DP."""
    if not markers: return []
    k = len(markers)
    dp = [1] * k
    prev = [-1] * k
    for i in range(k):
        for j in range(i - 1, -1, -1):
            if 1 <= markers[i][1] - markers[j][1] <= 2 and dp[j] + 1 > dp[i]:
                dp[i] = dp[j] + 1
                prev[i] = j
                break  # nearest j is best (keeps positions local)
    bi = max(range(k), key=lambda i: dp[i])
    chain = []
    while bi != -1:
        chain.append(markers[bi])
        bi = prev[bi]
    return chain[::-1]

MATH_PAT = re.compile(r'\b(ratio|percent|percentage|profit|loss|average|speed|train|interest|discount|marked price|selling price|cost price|work|days|wages|pipe|cistern|boat|stream|distance|angle|chord|tangent|radius|diameter|cylinder|cone|sphere|volume|surface|perimeter|area|triangle|circle|square|rectangle|cube|root|simplify|value of|lcm|hcf|divisib|remainder|sin|cos|tan|cot|sec|cosec|probability|data|table|chart|graph|income|expenditure|salary|population|metre|km|litre|kg|rs\.?|₹|fractions?|decimal)\b', re.I)
NONMATH_PAT = re.compile(r'\b(code|series|analogy|odd one|mirror image|water image|embedded|blood relation|direction|statement|syllogism|conclusion|arrangement|venn|matrix|word|meaning|sentence|blank|synonym|antonym|spelling|idiom|phrase|passage|cloze|who|whom|when|capital|river|festival|dynasty|constitution|amendment|cell|enzyme|planet|acid|war|treaty|awarded|nobel|sport|cricket|player|national park|biosphere|census|governor|president|prime minister)\b', re.I)

def math_score(txt):
    return len(MATH_PAT.findall(txt)) * 3 - len(NONMATH_PAT.findall(txt)) * 2

FIG_PAT = re.compile(r'\b(figure|diagram|pie chart|bar chart|bar graph|graph|आकृति|shown)\b', re.I)
TBL_PAT = re.compile(r'\b(data table|following table|below table|table given|table below)\b', re.I)

def _scan_opts(b, letters):
    """Backward scan for last consecutive letter-run (ABCD or 1234)."""
    ms = []
    for m in re.finditer(r'(?:^|\n|\s{2,}|[ \t])(' + '|'.join(letters) + r')(?:[\.\)]|(?=[ \t]*\n))', b):
        ms.append((m.start(1), m.end(), m.group(1)))
    d_pos = None
    for idx in range(len(ms) - 1, -1, -1):
        if ms[idx][2] == letters[-1]:
            d_pos = idx; break
    if d_pos is None: return None, b
    cand = {letters[-1]: ms[d_pos]}
    for k in range(len(letters) - 2, -1, -1):
        L, nxt = letters[k], letters[k + 1]
        found = None
        for idx in range(d_pos - 1, -1, -1):
            if ms[idx][2] == L and ms[idx][0] < cand[nxt][0]:
                found = ms[idx]; break
        if found is None: return None, b
        cand[L] = found
    # markers must be reasonably spaced (options zone)
    if cand[letters[-1]][0] - cand[letters[0]][0] > 1400:
        return None, b
    spans = {}
    for i, L in enumerate(letters):
        s = cand[L][1]
        e = cand[letters[i + 1]][0] if i + 1 < len(letters) else len(b)
        val = re.sub(r'\s*\n\s*', ' ', b[s:e]).strip()
        val = re.sub(r'Ans(?:wer)?[ \t]*[:.]?[ \t]*[A-D1-4]?[\.\)]?[ \t]*$', '', val).strip()
        spans[L] = val
    if not all(spans[L] for L in letters): return None, b
    if max(len(spans[L]) for L in letters) > 250: return None, b
    return spans, b[:cand[letters[0]][0]]

def split_qbody(num, body):
    b = body
    ans = None; ans_num = False
    m = re.search(r'(?:^|\n|\f)[ \t]*(?:Ans(?:wer)?[ \t]*[:.]?[ \t]*)([A-D]|[1-4])?[\.\)]?[ \t]*(?:\n|$)', b)
    if m and m.group(1):
        a = m.group(1)
        if a.isdigit():
            ans = 'ABCD'[int(a) - 1]; ans_num = True
        else:
            ans = a
        b = b[:m.start()] + b[m.end():]
    elif m:
        # "Ans" alone line; value may follow after options — try again later position
        b = b[:m.start()] + b[m.end():]
    opts, qtext = _scan_opts(b, list('ABCD'))
    numeric = False
    if not opts:
        o2, qt2 = _scan_opts(b, list('1234'))
        if o2:
            opts = {L: o2[d] for L, d in zip('ABCD', '1234')}
            qtext = qt2
            numeric = True
    if not opts:
        opts, qtext = {}, b
    opts_raw = ''
    if not opts and len(qtext) > 40:
        opts_raw = ' '.join(qtext.split())[-260:]
        qtext = ' '.join(qtext.split()[:-12])
    qtext = re.sub(r'(https?://\S+|Page[ \t]+\d+[ \t]+of[ \t]+\d+|Page-[ \t]*\d+|SSC CHSL[^\n]*Shift-?[ \t]*\d*|CHSL Exam[^\n]*\)|\f|^[ \t]*Ans(?:wer)?[ \t]*$)', ' ', qtext, flags=re.M)
    qtext = ' '.join(qtext.split())
    flags = []
    if FIG_PAT.search(qtext): flags.append('FIGURE')
    if TBL_PAT.search(qtext): flags.append('TABLE')
    if numeric: flags.append('NUMERIC_OPTS')
    if len(opts) != 4: flags.append('OPTIONS_' + str(len(opts)))
    if not ans: flags.append('NO_ANS')
    if len(qtext) < 15: flags.append('SHORT_TEXT')
    return {'n': num, 'text': qtext, 'options': opts, 'ans': ans, 'flags': flags,
            'opts_raw': opts_raw, 'score': math_score(qtext)}

def parse_block(sec, markers):
    out = []
    for i, (st, n, en) in enumerate(markers):
        nxt = markers[i + 1][0] if i + 1 < len(markers) else len(sec)
        out.append((st, n, split_qbody(n, sec[en:nxt])))
    return out

def select_math_window(parsed):
    # Prefer a perfectly-consecutive 25-question window
    best_perf = None
    for i in range(len(parsed)):
        win = parsed[i:i + 25]
        if len(win) == 25 and win[-1][1] - win[0][1] == 24:
            # all consecutive
            if all(win[k+1][1] - win[k][1] == 1 for k in range(24)):
                s = sum(q[2]['score'] for q in win)
                if best_perf is None or s > best_perf[0]:
                    best_perf = (s, win)
    if best_perf: return best_perf[1]
    best, best_score = None, -10**9
    for i in range(len(parsed)):
        win = parsed[i:i + 25]
        if len(win) < 20: continue
        if win[-1][1] - win[0][1] > 30: continue
        s = sum(q[2]['score'] for q in win) - (25 - len(win)) * 8
        if s > best_score:
            best_score, best = s, win
    return best

NOHDR_TEXT = {'2021_14.pdf','2021_26.pdf','2022_11.pdf','2022_14.pdf','2022_15.pdf'}

def extract_paper(fn, year):
    if year <= 2019:
        if year == 2019:
            sec = qa_section_bbox(fn)
            if sec is None:  # fallback: full 2-col + window
                sec = full_2col_text(fn)
                parsed = parse_block(sec, all_markers(sec))
                win = select_math_window(parsed)
                return [d for _, _, d in win] if win else None
            parsed = parse_block(sec, all_markers(sec))
            chain = best_chain(all_markers(sec))
            if chain:
                if len(chain) > 30:
                    pa = parse_block(sec, chain)
                    win = select_math_window(pa)
                    return [d for _, _, d in win] if win else [d for _, _, d in pa]
                return [d for _, _, d in parse_block(sec, chain)]
            return [d for _, _, d in parsed]
        else:  # 2017/2018
            sec = full_2col_text(fn)
            parsed = parse_block(sec, all_markers(sec))
            win = select_math_window(parsed)
            return [d for _, _, d in win] if win else None
    else:
        t = text_plain(fn)
        sec = qa_section_plain(t)
        if sec is not None and is_image_qa(sec):
            return None
        if sec is None:
            if os.path.basename(fn) in NOHDR_TEXT:
                sec = t
                parsed = parse_block(sec, all_markers(sec))
                win = select_math_window(parsed)
                return [d for _, _, d in win] if win else None
            return None
        parsed = parse_block(sec, all_markers(sec))
        chain = best_chain(all_markers(sec))
        if chain:
            if len(chain) > 30:
                pa = parse_block(sec, chain)
                win = select_math_window(pa)
                return [d for _, _, d in win] if win else [d for _, _, d in pa]
            return [d for _, _, d in parse_block(sec, chain)]
        return [d for _, _, d in parsed]

def main():
    results = {}
    for fn in sorted(os.listdir(CD)):
        m = re.match(r'(\d{4})_(\d{2})\.pdf', fn)
        if not m: continue
        y = int(m.group(1))
        if y == 2024: continue
        qs = extract_paper(os.path.join(CD, fn), y)
        if qs is None: continue
        results[fn] = qs
        bad = sum(1 for q in qs if any(f.startswith(('OPTIONS_', 'NO_ANS', 'SHORT')) for f in q['flags']))
        nums = [q['n'] for q in qs]
        print(f"{fn}: {len(qs)} Q [{nums[0] if nums else 0}-{nums[-1] if nums else 0}] bad {bad}", flush=True)
    with open(os.path.join(CD, 'extracted.json'), 'w') as f:
        json.dump(results, f, ensure_ascii=False, indent=1)
    ok = sum(1 for v in results.values() if len(v) == 25)
    print(f"\nTEXT papers parsed: {len(results)} | exact-25: {ok}")

if __name__ == '__main__':
    main()
