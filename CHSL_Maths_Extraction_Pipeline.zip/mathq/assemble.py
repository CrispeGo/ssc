#!/usr/bin/env python3
"""Assemble the final TXT: all CHSL Tier-I QA (math) questions 2024->2017."""
import json, os, re, sys

CD = '/var/tmp/mathq'
OUT = '/home/user/CHSL_Tier1_Maths_2024to2017.txt'

# ---------- name maps ----------
names = {}
for line in open(os.path.join(CD, 'dl.tsv')):
    parts = line.rstrip('\n').split('\t')
    if len(parts) >= 2:
        names[parts[0]] = parts[1].strip()
d = json.load(open(os.path.join(CD, 'b.json')))
for c in d['categories']:
    if str(c['name']).strip() == '2024':
        for i, e in enumerate(c['data'], 1):
            names[f'2024E_{i:02d}'] = e['name'].strip()
        break

# ---------- load all ----------
papers = []
extr = json.load(open(os.path.join(CD, 'extracted.json')))
for fn, qs in extr.items():
    papers.append({'id': fn[:-4], 'year': int(fn[:4]), 'qs': qs, 'src': 'text'})
for f in sorted(os.listdir(os.path.join(CD, 'ocr_out'))):
    qs = json.load(open(os.path.join(CD, 'ocr_out', f)))
    fid = f[:-5]
    yr = 2024 if fid.startswith('2024E') else int(fid[:4])
    papers.append({'id': fid, 'year': yr, 'qs': qs, 'src': 'ocr'})

papers.sort(key=lambda p: (-p['year'], p['id']))

# ---------- placeholders for missing question numbers ----------
for p in papers:
    qs = p['qs']
    if not qs: continue
    nums = [q['n'] for q in qs]
    lo = min(nums)
    hi = max(max(nums), min(nums) + 24)
    missing = sorted(set(range(lo, hi + 1)) - set(nums))
    for m in missing:
        qs.append({'n': m,
                   'text': '[Yeh question PDF me image roop me tha — OCR se poora padha nahi ja saka; original PDF dekhein]',
                   'options': {}, 'ans': None, 'flags': ['IMG_Q'], 'opts_raw': '', 'src': 'PLACEHOLDER'})
    qs.sort(key=lambda q: q['n'])

def clean_name(nm):
    return re.sub(r'\s+', ' ', nm).strip()

def fmt_paper(idx, p):
    nm = clean_name(names.get(p['id'], p['id']))
    qs = p['qs']
    n_ans = sum(1 for q in qs if q.get('ans'))
    src_desc = ('TEXT-layer se extract (accurate)' if p['src'] == 'text'
                else 'OCR se extract (scanned/image PDF)')
    L = []
    L.append('=' * 78)
    L.append(f"PAPER {idx:03d}  |  {p['year']}  |  {nm}  [Tier-I]")
    L.append(f"Source: {src_desc}  |  Questions: {len(qs)}  |  Answers mile: {n_ans}/{len(qs)}")
    L.append('=' * 78)
    for q in qs:
        L.append('')
        num = q.get('n', '?')
        src_tag = ''
        if p['src'] == 'text' and q.get('src') in ('OCR', 'OCR-GAP'):
            src_tag = ' [OCR-recovered]'
        L.append(f"Q{num}.{src_tag} {q.get('text','')}".rstrip())
        opts = q.get('options') or {}
        for k in 'ABCD':
            if opts.get(k):
                L.append(f"   ({k}) {opts[k]}")
        oraw = q.get('opts_raw')
        if oraw:
            L.append(f"   [Options raw/partial: {oraw}]")
        if q.get('ans'):
            aval = opts.get(q['ans'], '')
            note = q.get('ans_note', '')
            if aval:
                L.append(f"   >> Answer: ({q['ans']}) {aval}")
            elif note:
                L.append(f"   >> Answer: ({q['ans']})  [from key: {note}]")
            else:
                L.append(f"   >> Answer: ({q['ans']})")
        else:
            L.append("   >> Answer: [extract nahi ho paya — original PDF me dekhein]")
        flags = q.get('flags') or []
        fl = []
        for f in flags:
            if f == 'FIGURE': fl.append('Figure/Graph wala question — data image me hai, PDF dekhein')
            elif f == 'TABLE': fl.append('Data-table question (table text neeche/upar included hai)')
            elif f == 'IMG_Q': fl.append('Question image-based tha')
            elif f == 'IMG_Q_BODY': fl.append('Question ka text partially OCR hua hai')
            elif f.startswith('OPTIONS_'): fl.append(f'Options incomplete ({f})')
            elif f == 'NO_ANS': fl.append('Answer clear nahi')
            elif f == 'SHORT_TEXT': fl.append('Text adhura')
        if fl:
            L.append(f"   [Note: {'; '.join(fl)}]")
    L.append('')
    return '\n'.join(L)

# ---------- stats ----------
tot_q = sum(len(p['qs']) for p in papers)
tot_a = sum(sum(1 for q in p['qs'] if q.get('ans')) for p in papers)
per_year = {}
for p in papers:
    per_year.setdefault(p['year'], [0, 0, 0])
    per_year[p['year']][0] += 1
    per_year[p['year']][1] += len(p['qs'])
    per_year[p['year']][2] += sum(1 for q in p['qs'] if q.get('ans'))

H = []
H.append('=' * 78)
H.append('  SSC CHSL TIER-I — QUANTITATIVE APTITUDE (MATHS) QUESTIONS')
H.append('  2024 se 2017 tak | Sabhi available shifts | ~25 questions per paper')
H.append('=' * 78)
H.append('')
H.append(f'  TOTAL: {len(papers)} papers | {tot_q} questions | {tot_a} answers extracted')
H.append('')
H.append('  Year-wise breakdown (papers / questions / answers):')
for y in sorted(per_year, reverse=True):
    a, b, c = per_year[y]
    H.append(f'    {y}: {a:3d} papers | {b:4d} questions | {c:4d} answers')
H.append('')
H.append('  KAISE BANA HAI (honest disclosure):')
H.append('  - 2017-2023 (159 papers): PDF text-layer se extract kiya — sabse accurate.')
H.append('    * 2017-2018 papers 2-column the, geometry-aware extraction use hui.')
H.append('    * 2020 + kuch 2021/2022/2023 papers me questions images me the —')
H.append('      OCR (tesseract 300dpi) + color-checkmark answer detection se nikale.')
H.append('  - 2024 (34 papers): English PDFs pure scans hain — poora OCR (300dpi).')
H.append('    Hindi 2024 PDFs me bhi question-bodies images hi thin (options text the).')
H.append('  - Answers: text papers me "Ans/Answer" line se; image papers me')
H.append('    "Chosen Option" (text layer) ya green-tick (color detection) se;')
H.append('    kuch OCR answers verify nahi ho paye — unpe flag laga hai.')
H.append('  - [Figure/Graph] questions: graph/chart ka data image me hota hai;')
H.append('    jahan OCR se values nikal aayi wahan text me included hai.')
H.append('  - OCR wale questions me spelling/half-reading errors possible hain')
H.append('    (jaise "longths" for "lengths") — meaning clear rehta hai.')
H.append('  - Jahan question bilkul image tha aur OCR fail hua, wahan placeholder')
H.append('    diya hai — taaki koi question miss na lage, aap PDF me dekh sakte ho.')
H.append('')
H.append('  NOTE: Question numbers original PDF ke according hain (kuch papers me')
H.append('  QA section Q51-75 hota hai, kuch me Q151-175, kuch me Q1-25 restart).')
H.append('')
H.append('=' * 78)

body = [ '\n'.join(H) ]
for i, p in enumerate(papers, 1):
    body.append(fmt_paper(i, p))

txt = '\n'.join(body)
with open(OUT, 'w') as f:
    f.write(txt)
print(f"WROTE {OUT}: {len(papers)} papers, {tot_q} questions, {tot_a} answers, {len(txt)} chars")
